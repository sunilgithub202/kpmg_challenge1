import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class NestedMapLookup {

    public static String retrieveNested(String compositeKey, Map<String, Object> object) {
        if (compositeKey == null || compositeKey.isEmpty()) {
            throw new IllegalArgumentException("Key cannot be null or empty");
        }

        return retrieveValueRecursively(compositeKey, object);
    }

    private static String retrieveValueRecursively(String compositeKey, Map<String, Object> object) {
        if (object == null) {
            return null;
        }

        if (!compositeKey.contains("/")) {
            return object.get(compositeKey) == null ? null : String.valueOf(object.get(compositeKey));
        }

        String[] splitKey = compositeKey.split("/");
        String nextKey = splitKey[0];


        String restOfTheKey = String.join("/", Arrays.copyOfRange(splitKey, 1, splitKey.length));

        return retrieveValueRecursively(restOfTheKey, (Map<String, Object>) object.get(nextKey));
    }
}
