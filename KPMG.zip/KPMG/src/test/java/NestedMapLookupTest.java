import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class NestedMapLookupTest {

    private static final Map<String, Object> INPUT = new HashMap<>();

    @Before
    public void setUp() {
        Map<String, String> innermost = new HashMap<>();
        innermost.put("c", "d");

        Map<String, Object> middle = new HashMap<>();
        middle.put("b", innermost);
        INPUT.put("a", middle);
    }

    @Test
    public void retrieveNested() {
        Assert.assertEquals("d", NestedMapLookup.retrieveNested("a/b/c", INPUT));
        Assert.assertEquals("{c=d}", NestedMapLookup.retrieveNested("a/b", INPUT));
        Assert.assertEquals("{b={c=d}}", NestedMapLookup.retrieveNested("a", INPUT));
    }

    @Test
    public void retrieveNested_InvalidKey() {
        Assert.assertNull(NestedMapLookup.retrieveNested("a/b/x", INPUT));
        Assert.assertNull(NestedMapLookup.retrieveNested("x/y", INPUT));
    }

    @Test(expected = IllegalArgumentException.class)
    public void retrieveNested_EmptyInput() {
        NestedMapLookup.retrieveNested("", INPUT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void retrieveNested_NullInput() {
        NestedMapLookup.retrieveNested(null, INPUT);
    }
}
